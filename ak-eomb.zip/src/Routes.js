/* eslint-disable import/no-duplicates */
/* eslint-disable no-unused-vars */
import React from "react";
import { Route } from "react-router-dom";
import Login from './Modules/Login/Components/Login';
import Registration from './Modules/Registration/Components/Registration';
import ResetPassword from './Modules/ResetProfile/Components/ResetPassword';
import ForgotUsername from './Modules/ResetProfile/Components/ForgotUsername';
import PasswordRecovery from './Modules/ResetProfile/Components/PasswordRecovery';
import Success from './Modules/Registration/Components/Success';
import EOMBDetails from './Modules/EOMBDetails/Components/EOMBDetails';
import Chart from './Modules/FeedBack/Components/Charts/Chart';

export default function RoutesApp(props) {
  return (
    <React.Fragment>
      <Route exact path="/" component={Login} />
      <Route path="/login" component={Login} />
      <Route path="/registration" component={Registration} />
      <Route path="/resetPassword" component={ResetPassword} />
      <Route path="/forgotUsername" component={ForgotUsername} />
      <Route path="/forgotPassword" component={PasswordRecovery} />  
      <Route path="/success" component={Success} />  
      <Route path='/EOMBDetails' component={EOMBDetails} /> 
      <Route path='/Chart' component={Chart} /> 
    </React.Fragment>
  );
}
