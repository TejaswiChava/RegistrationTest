import React, { useEffect } from 'react';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import ReCAPTCHA from "react-google-recaptcha";
import * as serviceEndPoint from '../../../SharedModule/Service/service';

export default function ValidValueSearchForm(props) {
    const [values, setValues] = React.useState({
        userName: '',
        password: ''
    });
    const handleChanges = name => event => {
        setValues({ ...values, [name]: event.target.value });
    };
    const [showPassword, setShowPassword] = React.useState(false);

    // Captcha Details Start
    let captcha;

    const setCaptchaRef = (ref) => {
        if (ref) {
        return captcha = ref;
        }
    };

    function onCaptchaChange(value) {
        // const recaptchaValue = recaptchaRef.current.getValue(); // needed for future to get captcha value
        console.log("Captcha value:", value);
    }
    // Captcha Details End

    return (
        <div className="tabs-container">
            <div className="tab-body login-tab">
                <div className="tab-header">
                    <div className="tab-heading float-left">Login</div>
                </div>
                {!showPassword ?
                    <form autoComplete="off">
                        <div className="form-wrapper col-sm-12">
                            <div className="mui-custom-form">
                                <TextField
                                    id="standard-code"
                                    required
                                    label="User ID"
                                    fullWidth
                                    value={values.userName}
                                    onChange={handleChanges('userName')}
                                    placeholder=""
                                    inputProps={{ maxLength: 15 }}
                                    InputLabelProps={{
                                        shrink: true
                                    }} />
                            </div>
                        </div>
                        <div className="form-wrapper col-sm-12">
                            <a href="/forgotUsername" className="col-sm-8 float-left mr-4 mt-1" style={{ fontSize: '14px' }}>Forgot User ID?</a>
                            <Button className='btn btn-primary float-right col-sm-3 ml-1' onClick={() => setShowPassword(true)}>
                                Login </Button>
                        </div>
                        <div className="mt-2">
                            <hr></hr>
                            <div className="form-wrapper col-sm-12">
                                <a href="/registration" className="col-sm-12 float-left" style={{ fontSize: '14px' }}>Register New User</a>
                            </div>
                        </div>
                    </form> :

                    <form autoComplete="off">
                        <div className="form-wrapper col-sm-12">
                            <div className="mui-custom-form">
                                <TextField
                                    id="standard-code"
                                    required
                                    label="Password"
                                    fullWidth
                                    value={values.password}
                                    onChange={handleChanges('password')}
                                    placeholder=""
                                    inputProps={{ maxLength: 15 }}
                                    InputLabelProps={{
                                        shrink: true
                                    }} />
                            </div>
                        </div>
                        <div className="">
                            <hr></hr>
                            <ReCAPTCHA className="mt-1 ml-5 mb-1"
                            ref={(r) => setCaptchaRef(r) }
                            sitekey={serviceEndPoint.SITE_KEY}
                            onChange={onCaptchaChange}
                            />
                            <div className="form-wrapper col-sm-12 p-0 ml-2">
                                <div className="sub-radio">
                                    <FormControlLabel className="col-sm-1 py-0 my-0"
                                        control={
                                            <Checkbox
                                                color="primary"
                                            />
                                        }
                                        label="I"
                                    />
                                     <span className="col-sm-11 ml-2" style={{ fontSize: '14px' }}> have read and agree with the <a href="">Terms of Use</a> and <a href="">Privacy Policy</a></span>
                                </div>
                            </div>
                            <hr></hr>
                        </div>
                        <div className="form-wrapper col-sm-12 my-2">
                            <a href="/forgotPassword" className="col-sm-8 float-left mr-4 mt-1" style={{ fontSize: '14px' }}>Forgot Password/Unlock Account</a>
                            <Button className='col-sm-3 btn btn-primary float-right ml-1'>
                                Login </Button>
                        </div>
                    </form>}
            </div>
        </div>
    )
}
