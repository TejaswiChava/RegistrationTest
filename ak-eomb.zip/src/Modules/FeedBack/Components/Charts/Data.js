export const grossFeedbackData = [{
  feedback: 'Correct Service',
  yes: 21,
  no: 7,
  other: 12
}, {
  feedback: 'Correct Rendering Provider',
  yes: 18,
  no: 13,
  other: 9
}, {
  feedback: 'Correct Date(s) of Service',
  yes: 31,
  no: 5,
  other: 4
}, {
  feedback: 'Correct Copay',
  yes: 24,
  no: 4,
  other: 12
}];
