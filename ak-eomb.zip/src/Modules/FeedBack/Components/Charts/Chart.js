import React from 'react';
import './Chart.scss';
import { Chart, Series, CommonSeriesSettings, Label, Format, Legend, Export, ValueAxis } from 'devextreme-react/chart';
import { grossFeedbackData } from './Data.js';

class App extends React.Component {

  render() {
    return (
      <Chart className="chart-container"
        // title="Chart Title"
        dataSource={grossFeedbackData}
        onPointClick={this.onPointClick}
      >
        <CommonSeriesSettings
          argumentField="feedback"
          type="bar"
          hoverMode="allArgumentPoints"
          selectionMode="allArgumentPoints"
          barWidth='50'
          barPadding="10"
        >
          <Label visible={true}>
            <Format type="fixedPoint" precision={0} />
          </Label>
        </CommonSeriesSettings>
        <Series
          argumentField="feedback"
          color="rgb(0,131,123)"
          valueField="yes"
          name="Yes"
        />
        <Series
          color="rgb(0,71,186)"
          valueField="no"
          name="No"
        />
        <Series
          color="rgb(102,58,182)"
          valueField="other"
          name="Other"
        />
        <ValueAxis
          position="left"
          // tickInterval={2}
          max={50}
          showZero={true}
          valueMarginsEnabled={true} />
        <Legend verticalAlignment="bottom" horizontalAlignment="center"></Legend>
        <Export enabled={true} />
      </Chart>
    );
  }

  onPointClick(e) {
    e.target.select();
  }
}

export default App;
