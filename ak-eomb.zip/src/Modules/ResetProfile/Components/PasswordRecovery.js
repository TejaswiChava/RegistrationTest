import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import './ResetProfile.scss';  

export default function PasswordRecoveryForm(props) {
    const [values, setValues] = React.useState({
        secQs1: 'Security Question 1?',
        secQs2: 'Security Question 2?',
        secQs3: 'Security Question 3?'
    });
    const handleChanges = name => event => {
        setValues({ ...values, [name]: event.target.value });
    };

    return (
            <div className="tabs-container">
                <div className="tab-body password-reset-container">
                    <div className="tab-header">
                        <div className="tab-heading float-left">Password Recovery</div>
                    </div>
                    <form autoComplete="off">
                        {/* <div className="form-wrapper row ml-3 mt-0 mb-0 pl-1">
                            <p className="text-danger">Unable to reset the password due to invalid attempt.</p>
                        </div> */}
                        <div className="form-wrapper row ml-3 mt-0 mb-0">
                            <div className="mui-custom-form col-sm-4 ml-0 pl-1">
                                <TextField
                                required
                                id="standard-username"
                                label="User ID"
                                inputProps={{ maxlength: 15 }}
                                InputLabelProps={{
                                    shrink: true
                                }}
                                />
                            </div>
                        </div>
                        <div className="form-wrapper row ml-4 mt-1 mb-0">
                            <h5 className="password-recovery-subheader">Please answer below questions</h5>
                        </div>
                        <div className="ml-4 mr-4">
                        <fieldset className="custom-fieldset pl-0 mt-3">
                            <legend>Security Questions:</legend>
                            <div className="row">
                                <div className="col pr-0">
                                    <div className="mui-custom-form col-sm-12">
                                        <TextField
                                            required
                                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                                            id="standard-sq1"
                                            value={values.secQs1}
                                            label="Security Question 1?"
                                            inputProps={{ maxlength: 15 }}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form col-sm-12">
                                        <TextField
                                            required
                                            id="standard-ans1"
                                            label="Answer"
                                            inputProps={{ maxlength: 15 }}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="col p-0">
                                    <div className="mui-custom-form col-sm-12">
                                        <TextField
                                            required
                                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                                            id="standard-sq2"
                                            value={values.secQs2}
                                            label="Security Question 2?"
                                            inputProps={{ maxlength: 15 }}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form col-sm-12">
                                        <TextField
                                            required
                                            id="standard-ans2"
                                            label="Answer"
                                            inputProps={{ maxlength: 15 }}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="col pl-0">
                                <div className="mui-custom-form col-sm-12">
                                    <TextField
                                        required
                                        InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                                        id="standard-sq3"
                                        value={values.secQs3}
                                        label="Security Question 3?"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form col-sm-12">
                                    <TextField
                                        required
                                        id="standard-ans3"
                                        label="Answer"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                    />
                                </div>
                            </div>
                            </div>
                        </fieldset>
                    </div>
                        <div className="form-wrapper offset-sm-9 pl-3">
                            <Button className='btn btn-primary my-2'>
                                Submit </Button>
                            <Button className='btn btn-transparent bt-cancel m-2'>
                                Cancel </Button>
                        </div>
                    </form>
                </div>
            </div>
    )
}
