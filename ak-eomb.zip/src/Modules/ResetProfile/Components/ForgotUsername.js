import React from 'react';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import './ResetProfile.scss';  

export default function ForgotUserNameForm(props) {
    

    return (
            <div className="tabs-container">
                <div className="tab-body forgot-username-container">
                    <div className="tab-header">
                        <div className="tab-heading float-left">Forgot User ID Form</div>
                    </div>
                    <form autoComplete="off">
                        <div className="form-wrapper row m-3">
                            <div className="col">
                                <div className="form-wrapper row">
                                    <div className="mui-custom-form">
                                        <TextField
                                        required
                                        id="standard-email-address"
                                        label="Email Address"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        />
                                    </div>
                                    <div className="mui-custom-form">
                                        <TextField
                                        required
                                        id="standard-member-ID"
                                        label="Member ID"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                            <div className="form-wrapper col-sm-12">
                                <div className="forgot-username-text-container">
                                    <ol>
                                        <li>Please enter your registered Email Address.</li>
                                        <li>User ID must be sent to your registered Email Address.</li>
                                    </ol>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="form-wrapper offset-sm-9">
                            <Button className='btn btn-primary ml-0 mr-2 mt-2 mb-2'>
                                Submit </Button>
                            <Button className='btn btn-transparent bt-cancel m-2'>
                                Cancel </Button>
                        </div>
                    </form>
                </div>
            </div>
    )
}
