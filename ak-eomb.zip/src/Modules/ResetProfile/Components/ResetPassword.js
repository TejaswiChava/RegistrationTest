import React from 'react';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import './ResetProfile.scss';  

export default function ResetPasswordForm(props) {
    return (
            <div className="tabs-container">
                <div className="tab-body password-reset-container">
                    <div className="tab-header">
                        <div className="tab-heading float-left">Change my Password</div>
                    </div>
                    <form autoComplete="off">
                        <div className="form-wrapper row m-3">
                            <div className="col">
                                <div className="form-wrapper row">
                                    <div className="mui-custom-form">
                                        <TextField
                                        required
                                        id="standard-current-password"
                                        label="Current Password"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper row">
                                    <div className="mui-custom-form">
                                        <TextField
                                        required
                                        id="standard-new-password"
                                        label="New Password"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper row">
                                    <div className="mui-custom-form">
                                        <TextField
                                        required
                                        id="standard-confirm-password"
                                        label="Confirm New Password"
                                        inputProps={{ maxlength: 15 }}
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                            <div className="form-wrapper col-sm-12">
                                <div className="password-reset-text-container">
                                    <ol>
                                        <li>Password must be a minimum of 8 characters.</li>
                                        <li>Password must be different from your last 5 passwords.</li>
                                        <li>Password must contain at least 3 of the 4 following types:</li>
                                        <ul>
                                            <li>Uppercase letters</li>
                                            <li>Lowercase letters</li>
                                            <li>Numbers</li>
                                            <li>Non-Alphanumeric (!, $, #, or %)</li>
                                        </ul>
                                    </ol>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="form-wrapper offset-sm-9">
                            <Button className='btn btn-primary my-2'>
                                Change </Button>
                                <Button className='btn btn-transparent bt-cancel my-2 ml-2'>
                                Cancel </Button>
                        </div>
                    </form>
                </div>
            </div>
    )
}
