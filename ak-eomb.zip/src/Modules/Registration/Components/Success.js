import React from 'react';
import { Button } from 'react-bootstrap';
import './Registration.scss';

export default function RegistrationSuccessForm(props) {
    return (
        <div className="tabs-container success-container">
            <div className="tab-body">
                <div className="tab-header">
                    <div className="tab-heading float-left col-sm-12">Congratulations!</div>
                </div>
                <div className="form-wrapper row ml-3 mt-0 mb-0 pl-1">
                    <p className="text-normal p-1">You have successfully registered for web access. You will receive a confirmation of your registration via the email you entered. Please use login page to continue.</p>
                </div>
                <div className="form-wrapper offset-sm-8 pl-5">
                    <Button className='btn btn-primary my-2'>
                        Resend Email </Button>
                    <Button className='btn btn-transparent bt-cancel m-2'>
                        Login </Button>
                </div>
            </div>
        </div>
    )
}
