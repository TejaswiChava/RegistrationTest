import React from 'react';
import Table from '../../../SharedModule/Layout/Table';

export default function RegistrationForm(props) {
  return (
    <div className="container">
      <div class="topnav" id="myTopnav" align="right" style={{fontSize: '15px'}}>
        <a href="/resetPassword">Reset Password</a>
        <span class="px-1">|</span>
        <a href="#" data-toggle="tooltip" data-placement="right" title="(800) 770-5650">Contact Us
        </a>
        <span class="px-1">|</span>
        <a href="#">Log out</a>
      </div>
      <div className="topnav bg-light p-2 m-1">
        <p className="my-1">Member name: <span className="font-weight-bold">John K. Smith</span></p>
      </div>
      <Table lineLevel={true} />
    </div>

  )
}
