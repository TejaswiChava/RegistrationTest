export const NUMBER_ONLY_REGEX = /[a-zA-Z!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~ ]/;
export const PHONE_NUMBER_ONLY_REGEX = /[a-zA-Z!@#$%^&*()_\=[\]{};':"\\|,.<>/?~ ]/;
export const EMAIL_ADDRESS_REGEX = /^[\w-]+@([\w-]+\.)+[\w-]+$/;
export const PLEASE_SELECT_ONE = 'Please Select One';
export const SELECT_QUESTION = 'Select a Question';