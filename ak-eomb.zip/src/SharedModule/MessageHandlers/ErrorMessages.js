/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

export default function DisplayErrorMessages (props) {
  return <div className="w-100">{props.errorMessages.length > 0 ? <div className="alert alert-danger custom-alert" role="alert" >
    {props.errorMessages.map((message, index) => <li key ={index}>{message}</li>)
    }
  </div> : null
  }</div>;
}

DisplayErrorMessages.propTypes = {
  errorMessages: PropTypes.array.isRequired
};
