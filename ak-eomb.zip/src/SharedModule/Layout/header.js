import React from 'react';
import Routes from '../../Routes'

export default function Header(props) {

    return (
        <div className="main-container">
            <div className="header-container">
                <img src="stateLogo.jpg" alt="State Logo" style={{ marginLeft: '13%' }}></img>
            </div>
            <Routes />
        </div>
    )
}
