import React from 'react';
import PropTypes from 'prop-types';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import './Layout.scss';
import TextField from '@material-ui/core/TextField';
import numeral from 'numeral';
import { Button } from 'react-bootstrap';

function Row(props) {
  const { row, index, rowIndex, onClickRow, lineLevel, cIndex, setCIndex } = props;
  // const [cIndex, setCIndex] = React.useState(-1);
  const onClickSubRow = i => {
    setCIndex(cIndex === i ? -1 : i);
  }

  return (
    <React.Fragment>
      <TableRow className="" onClick={() => onClickRow(index)}>
        <TableCell component="th" scope="row">
          <a href="#">{row.mos}</a>
        </TableCell>
        <TableCell >{row.amtPaid}</TableCell>
        <TableCell ><a href="/registration">{row.pdf}</a></TableCell>
        <TableCell align="right">
          <IconButton aria-label="expand row" size="small">
            {index === rowIndex ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
      </TableRow>
      <TableRow className="no-hover-color">
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={index === rowIndex } timeout="auto" unmountOnExit>
            <Box margin={1} padding={2}>
              <Table size="small" aria-label="purchases" className="table">
                <TableHead>
                  <TableRow>
                    <TableCell>TCN</TableCell>
                    <TableCell>Date of Service</TableCell>
                    <TableCell>Billing Provider</TableCell>
                    <TableCell hidden={!lineLevel}>Rendering Provider</TableCell>
                    <TableCell hidden={!lineLevel}>Description of Service</TableCell>
                    <TableCell hidden={!lineLevel}>Surgical Procedure</TableCell>
                    <TableCell>Primary Diagnosis</TableCell>
                    <TableCell>Amount Paid</TableCell>
                    <TableCell hidden={!lineLevel}>Copay</TableCell>
                    <TableCell><span hidden>Toggle</span></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {row.subData.map((historyRow, index) => (
                    <React.Fragment>
                      <TableRow key={historyRow.tcn} onClick={() => { onClickSubRow(index) }}>
                        <TableCell component="th" scope="row">
                        <a href="#">{historyRow.tcn}</a>
                        </TableCell>
                        <TableCell>{historyRow.dos}</TableCell>
                        <TableCell>{historyRow.billingProvider}</TableCell>
                        <TableCell hidden={!lineLevel}>{historyRow.renderingProvider}</TableCell>
                        <TableCell hidden={!lineLevel}>{historyRow.descOfServ}</TableCell>
                        <TableCell hidden={!lineLevel}>{historyRow.spDesc.map((spRow, index) => (
                           <p>{spRow}</p>
                        ))}</TableCell>
                        <TableCell>{historyRow.pdDesc}</TableCell>
                        <TableCell>{historyRow.amtPaid}</TableCell>
                        <TableCell hidden={!lineLevel}>{historyRow.copay}</TableCell>
                        <TableCell>
                          <IconButton aria-label="expand row" size="small">
                            {index === cIndex? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                          </IconButton>
                        </TableCell>
                      </TableRow>
                      <TableRow className="no-hover-color">
                        { index === cIndex ? <SubRow row={row} indexVal={index === cIndex?true:false} lineLevel={lineLevel}/> : null}
                      </TableRow>
                    </React.Fragment>
                  ))}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}
function SubRow(props) {
  const { row , indexVal, lineLevel} = props;
  const [values, setValues] = React.useState({
    feedback: ''
  });

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };

  return (
    <React.Fragment>
      <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={lineLevel? 10:7}>
        <Collapse in={indexVal} timeout="auto" unmountOnExit>
          <Box margin={1} padding={2}>
            <Table size="small" aria-label="purchases" className="table" hidden={lineLevel}>
              <TableHead>
                <TableRow>
                  <TableCell>Line Item Number</TableCell>
                  <TableCell>Date of Service</TableCell>
                  <TableCell >Rendering Provider</TableCell>
                  <TableCell >Description of Service</TableCell>
                  <TableCell >Amount Paid</TableCell>
                  <TableCell >Copay</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {row.lineLevelData.map((historyRow) => (
                  <React.Fragment>
                    <TableRow key={historyRow.los}>
                      <TableCell component="th" scope="row">
                        {historyRow.los}
                      </TableCell>
                      <TableCell>{historyRow.dos}</TableCell>
                      <TableCell>{historyRow.renderingProvider}</TableCell>
                      <TableCell>{historyRow.descOfServ}</TableCell>
                      <TableCell >{historyRow.amtPaid}</TableCell>
                      <TableCell >{historyRow.copay}</TableCell>
                    </TableRow>
                    <TableRow></TableRow>
                  </React.Fragment>
                ))}
              </TableBody>

            </Table>
            <div className="row">
              <div class="col form-group col-sm-12 mb-0">
                <p className="p-0 my-0">Did you get this service?</p>
                <div className="row ml-0 mt-2">
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="Yes"
                    id="check-yes1"
                    checked={true}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-yes1">
                    Yes
                  </label>
                </div>
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="No"
                    id="check-no1"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-no1">
                    No
                  </label>
                </div>
                <div className="px-0 py-2">
                  <input
                    type="radio"
                    value="Others"
                    id="check-others"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-others">
                    Others
                  </label>
                </div>
                  <div className="mui-custom-form col-sm-4 ml-0 my-0">
                    <label for="text-others1" hidden>Others</label>
                    <TextField
                      id="text-others1"
                      required
                      fullWidth
                      disabled
                      // value={values.userName}
                      // onChange={handleChanges('userName')}
                      placeholder=""
                      inputProps={{ maxLength: 15 }}
                      InputLabelProps={{
                        shrink: true
                      }} />
                  </div>
                </div>
              </div>
              <div class="col form-group col-sm-12 mb-0">
                <p className="p-0 my-0">Did you see this service provider?</p>
                <div className="row ml-0 mt-2">
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="Yes"
                    id="check-yes2"
                    // checked={true}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-yes2">
                    Yes
                  </label>
                </div>
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="No"
                    id="check-no2"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-no2">
                    No
                  </label>
                </div>
                <div className="px-0 py-2">
                  <input
                    type="radio"
                    value="Others"
                    id="check-others2"
                    checked={true}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-others2">
                    Others
                  </label>
                </div>
                  <div className="mui-custom-form col-sm-4 ml-0 my-0">
                  <label for="text-others2" hidden>Others</label>
                    <TextField
                      id="text-others2"
                      required
                      fullWidth
                      // value={values.userName}
                      // onChange={handleChanges('userName')}
                      placeholder=""
                      inputProps={{ maxLength: 15 }}
                      InputLabelProps={{
                        shrink: true
                      }} />
                  </div>
                </div>
              </div>
              <div class="col form-group col-sm-12 mb-0">
                <p className="p-0 my-0">Did you see this provider on this date?</p>
                <div className="row ml-0 mt-2">
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="Yes"
                    id="check-yes3"
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-yes3">
                    Yes
                  </label>
                </div>
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="No"
                    id="check-no3"
                    checked={true}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-no3">
                    No
                  </label>
                </div>
                <div className="px-0 py-2">
                  <input
                    type="radio"
                    value="Others"
                    id="check-others3"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-others3">
                    Others
                  </label>
                </div>
                  <div className="mui-custom-form col-sm-4 ml-0 my-0">
                  <label for="text-others3" hidden>Others</label>
                    <TextField
                      id="text-others3"
                      required
                      fullWidth
                      disabled
                      // value={values.userName}
                      // onChange={handleChanges('userName')}
                      placeholder=""
                      inputProps={{ maxLength: 15 }}
                      InputLabelProps={{
                        shrink: true
                      }} />
                  </div>
                </div>
              </div>
              <div class="col form-group col-sm-12 mb-0">
                <p className="p-0 my-0">Did you pay this Copay amount for this service?</p>
                <div className="row ml-0 mt-2">
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="Yes"
                    id="check-yes4"
                    checked={true}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-yes4">
                    Yes
                  </label>
                </div>
                <div className="col-sm-2 px-0 py-2">
                  <input
                    type="radio"
                    value="No"
                    id="check-no4"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-no4">
                    No
                  </label>
                </div>
                <div className="px-0 py-2">
                  <input
                    type="radio"
                    value="Others"
                    id="check-others4"
                    // checked={values.descriptionSelected === 'StartsWith'}
                    // onChange={handleChange('descriptionSelected')}
                  />
                  <label className="text-black ml-2" htmlFor="check-others4">
                    Others
                  </label>
                </div>
                  <div className="mui-custom-form col-sm-4 ml-0 my-0">
                  <label for="text-others4" hidden>Others</label>
                    <TextField
                      id="text-others4"
                      required
                      fullWidth
                      disabled
                      // value={values.userName}
                      // onChange={handleChanges('userName')}
                      placeholder=""
                      inputProps={{ maxLength: 15 }}
                      InputLabelProps={{
                        shrink: true
                      }} />
                  </div>
                </div>
              </div>
              <div className="container">
                  <div className="row justify-content-end pr-3">
                  <Button className='btn btn-primary ml-0 mr-2 mt-2 mb-2'>
                      Save Feedback </Button>
                  </div>
              </div>
            </div>
          </Box>
        </Collapse>
      </TableCell>
    </React.Fragment>
  );
}
Row.propTypes = {
  row: PropTypes.shape({
    calories: PropTypes.number.isRequired,
    carbs: PropTypes.number.isRequired,
    fat: PropTypes.number.isRequired,
    history: PropTypes.arrayOf(
      PropTypes.shape({
        amount: PropTypes.number.isRequired,
        customerId: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
      }),
    ).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    protein: PropTypes.number.isRequired,
  }).isRequired,
};
const spList1 = ['Insertion of totally Implantable Vascular Access Device into Chest Subcutaneous Tissue and Fascia, Percutaneous Approach ','Extraction of Iliac Bone Marrow, Percutaneous Approach, Diagnostic', 'Drainage of Spinal Canal, Percutaneous Approach, Diagnostic', 'Drainage of Spinal Canal, Percutaneous Approach, Diagnostic', 'Drainage of Spinal Canal, Percutaneous Approach, Diagnostic'];
const spList2 = ['Total pancreatectomy'];


const subRows = [
  { tcn: '18064703010000040', dos: '07/10/2018-07/13/2018', billingProvider: 'Provident Medical Center of North Carolina', renderingProvider: 'Judy Susan', descOfServ: 'Inpatient Hospital Stay or Inpatient Surgery Service', spDesc: spList1, pdDesc: 'Postprocedural pneumothorax', amtPaid: '$5373.00', copay: '$50.00' },
  { tcn: '18098300040000110', dos: '07/14/2018-07/15/2018', billingProvider: 'Provident Medical Center of North Carolina', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', spDesc: spList2, pdDesc: 'Kyphosis NEC', amtPaid: '5000.75', copay: '$50.99' },
  // { tcn: '18094300040004120', dos: '07/17/2018-07/18/2018', billingProvider: 'Provident Medical Center of North Carolina', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', spDesc: 'Proximal pancreatectomy', pdDesc: 'Lordosis NOS', amtPaid: '$22.00', copay: '$19.00' },
  // { tcn: '18094300040004510', dos: '07/20/2018-07/25/2018', billingProvider: 'Provident Medical Center of North Carolina', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', spDesc: 'Distal pancreatectomy', pdDesc: 'Idiopathic scoliosis', amtPaid: '$22.00', copay: '$18.00' },
];
const lineLevelRows = [
{ los: '1', dos: '07/10/2018-07/13/2018', renderingProvider: 'Judy Susan', descOfServ: 'Bcg Vaccine Intravesica', amtPaid: '$19.00', copay: '$12.01' },
{ los: '2', dos: '07/10/2018-07/13/2018', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', amtPaid: '$7.00', copay: '$5.01' },
{ los: '3', dos: '07/10/2018-07/13/2018', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', amtPaid: '$22.01', copay: '$20.01' },
{ los: '4', dos: '07/10/2018-07/13/2018', renderingProvider: 'Aaron Madisson', descOfServ: 'Cholera Vaccine Live Oral', amtPaid: '$9.00', copay: '$6.01' },
];
const rows = [
  { mos: 'Jul 2018', amtPaid: '$10373.75', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Jun 2018', amtPaid: '$234.80', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'May 2018', amtPaid: '$344.80', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Apr 2018', amtPaid: '$0.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Mar 2018', amtPaid: '$0.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Feb 2018', amtPaid: '$91.80', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Jan 2018', amtPaid: '$111.60', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Dec 2017', amtPaid: '$0.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Nov 2017', amtPaid: '$73.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Oct 2017', amtPaid: '$34.20', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Sep 2017', amtPaid: '$771.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows },
  { mos: 'Aug 2017', amtPaid: '$61.00', pdf: 'PDF', subData: subRows, lineLevelData: lineLevelRows }
];


export default function CollapsibleTable(props) {
  const { lineLevel } = props;
  const [rowIndex,setRowIndex] = React.useState(-1);
  const [cIndex, setCIndex] = React.useState(-1);
  const onClickRow = i => {
    setCIndex(-1);
    setRowIndex(rowIndex === i ? -1 : i);
  }
  return (
    <TableContainer className="mb-4" component={Paper}>
      <Table aria-label="collapsible table" className="table my-0">
        <TableHead>
          <TableRow>
            <TableCell>Month of service</TableCell>
            <TableCell >Amount Paid</TableCell>
            <TableCell >Download PDF</TableCell>
            <TableCell align="right"><span hidden>Toggle</span></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row, index) => (
            <Row key={row.name} onClickRow={onClickRow} rowIndex={rowIndex} setCIndex={setCIndex} cIndex={cIndex} index={index} row={row} lineLevel={lineLevel}/>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
